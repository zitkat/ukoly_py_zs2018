# lists_tuples
lekce pyladies Plzen
- pro nazornou vyuku seznamu a ntic jsou pripravene casti kodu a ukolu pro ozkouseni, inspirovane prazskym kurzem 2017 
Diky za inspiraci.
